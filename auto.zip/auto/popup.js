//拡張機能上のスクリプト

console.log("this is popup.js");

document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("executeScript").addEventListener("click", function() {
      const StartHhValue = document.getElementById("StartHh").value;
      const StartMmValue = document.getElementById("StartMm").value;
      const EndHhValue = document.getElementById("EndHh").value;
      const EndMmValue = document.getElementById("EndMm").value;

      const workPtnValue = document.getElementById("workPtn").value;
  
      chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.scripting.executeScript({
          target: {tabId: tabs[0].id},
          function: executeContentScript,
          args: [StartHhValue,StartMmValue,EndHhValue,EndMmValue,workPtnValue]
        });
      });
    });

    document.getElementById("holidayScript").addEventListener("click",function(){
      chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.scripting.executeScript({
          target: {tabId: tabs[0].id},
          function: setHolidayScript
        });
      });
    });
  });
  
  function executeContentScript(StartHhValue,StartMmValue,EndHhValue,EndMmValue,workPtnValue) {
    // content.jsの関数を実行する
    myFunction(StartHhValue,StartMmValue,EndHhValue,EndMmValue, workPtnValue);
  }
  
  function setHolidayScript(){
    setHoliday();
  }

  