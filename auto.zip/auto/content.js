//e-革新上のスクリプト
console.log("this is content.js");

//全行取得
const rows = document.querySelectorAll('[id^=rowId]');
//行数
let rowsIndex = rows.length;

/**
 * 
 * @param {勤務開始時} StartHhValue 
 * @param {勤務開始分} StartMmValue
 * @param {勤務終了時} EndHhValue 
 * @param {勤務終了分} EndMmValue 
 * @param {勤務パターン} workPtnValue 
 */
function myFunction(StartHhValue,StartMmValue,EndHhValue,EndMmValue,workPtnValue){

    //debug用
    console.log(StartHhValue,StartMmValue,EndHhValue,EndMmValue, workPtnValue);
    console.log(rows);

 for(let i=0;i<rowsIndex;i++){

    //勤務パターンを指定のものにする　固定_8:00 
    rows[i].children[3].children[0].value = workPtnValue;

    //勤務状況　を空白に
    rows[i].children[4].children[0].value = "";

    //勤務時間を一括でセット
    document.getElementsByName(`workBeanList[${i}].scdBgnHh`)[0].value = StartHhValue
    document.getElementsByName(`workBeanList[${i}].scdBgnMi`)[0].value = StartMmValue
    document.getElementsByName(`workBeanList[${i}].scdEndHh`)[0].value = EndHhValue
    document.getElementsByName(`workBeanList[${i}].scdEndMi`)[0].value = EndMmValue

    }

}

