//e-革新上のスクリプト
console.log("this is content.js");

//全行取得
const rows = document.querySelectorAll('[id^=rowId]');
console.log(rows);
//行数
let rowsIndex = rows.length;

/**
 * 
 * @param {勤務開始時} StartHhValue 
 * @param {勤務開始分} StartMmValue
 * @param {勤務終了時} EndHhValue 
 * @param {勤務終了分} EndMmValue 
 * @param {勤務パターン} workPtnValue 
 */
function myFunction(StartHhValue,StartMmValue,EndHhValue,EndMmValue,workPtnValue){

    //debug用
    console.log(StartHhValue,StartMmValue,EndHhValue,EndMmValue, workPtnValue);
    console.log(rows);

 for(let i=0;i<rowsIndex;i++){

    //勤務パターンを指定のものにする　固定_8:00 
    rows[i].children[3].children[0].value = workPtnValue;

    //勤務状況　を空白に
    rows[i].children[4].children[0].value = "";

    //勤務時間を一括でセット
    document.getElementsByName(`workBeanList[${i}].scdBgnHh`)[0].value = StartHhValue
    document.getElementsByName(`workBeanList[${i}].scdBgnMi`)[0].value = StartMmValue
    document.getElementsByName(`workBeanList[${i}].scdEndHh`)[0].value = EndHhValue
    document.getElementsByName(`workBeanList[${i}].scdEndMi`)[0].value = EndMmValue

    }

    changeAllColor();
        
}


    //　カレンダーカラー
    var cldKbnTbl = new Array(
            
        '0',
        '#C1FAFB',

        '1',
        '#FF3399',

        '2',
        '#EE82EE',

        '3',
        '#FFC0CB',

    "");


var changeCldKbn = index => {
    var cldKbn = parseInt(document.forms[0]["workBeanList[" + index + "].cldKbn"].value);

    document.forms[0]["workBeanList[" + index + "].cldKbn"].value = cldKbnTbl[(cldKbn * 2 + 2) % 8];
    document.getElementById("rowId[" + index + "]").style.background = cldKbnTbl[(cldKbn * 2 + 3) % 8];
}

//色を勤務カラーの青に一括変更
var changeAllColor = () => {
    for(let i=0; i<rowsIndex;i++){
        // 背景色取得    
        let bgColor = rows[i].style.backgroundColor
        
        //日 3回実行
        if(bgColor=="rgb(255, 51, 153)"||bgColor=="FF3399"){
            for(let count_i=0;count_i<3;count_i++){
                changeCldKbn(i);
            }
        }
        //土曜 2回実行
        else if(bgColor=="rgb(238, 130, 238)"||bgColor=="EE82EE"){
            for(let count_i=0;count_i<2;count_i++){
                changeCldKbn(i);
            }
        }
        //祝 1回実行
        else if(bgColor=="rgb(255, 192, 203)"||bgColor=="EE82EE"){
            changeCldKbn(i);
        }
    }
}

let workStatus; 
function setHoliday(){

    for(let i=0;i<rowsIndex;i++){

        //勤務状況
        workStatus = rows[i].children[4].children[0].value;
    
            //休⇨赤にする
            if(workStatus=="0010"){
                changeCldKbn(i);
            }
    
    }

}



