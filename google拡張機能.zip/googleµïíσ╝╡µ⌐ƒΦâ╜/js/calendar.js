//読み込み完了時の処理
document.addEventListener('DOMContentLoaded',function(){

const calendar = document.getElementById("calendar");
const yearMonth = document.querySelector(".yearMonth");
  
const shiftYear = document.getElementById("shiftYear");
const shiftMonth = document.getElementById("shiftMonth");

const date = new Date();
let year = date.getFullYear();
let nextyear = date.getFullYear()+1;//来年表示用　12月のとき
let month = date.getMonth() + 1;
// let month = 12;//12月テスト用データ
let nextmonth = month + 1;

//12月の時は翌月を1月へ
if(month==12){
  nextmonth=1;
}

let calendarHtml = ""; // カレンダー用HTMLを組み立てる変数
let shiftYMHtml = "";

  //デフォルト　来月分カレンダー表示
  if(month==12){
    createCalendar(nextyear,nextmonth);
  }else{
    createCalendar(year,nextmonth);
  }

  //年プルダウン時
  shiftYear.addEventListener('change',function(){
    if(shiftYear.value==nextyear){
      shiftMonth.value = nextmonth;
    }else if(shiftYear.value==year){
      shiftMonth.value = month;
    }

    calendar.childNodes[0].remove();
    createCalendar(
                    shiftYear.value,
                    shiftMonth.value
                    );
    
  });
  //月プルダウン時
  shiftMonth.addEventListener('change',function(){
    if(shiftMonth.value==1){
      shiftYear.value = nextyear;
    }else if(shiftMonth.value==12){
      shiftYear.value = year;
    }

    calendar.childNodes[0].remove();
    createCalendar(
                    shiftYear.value,
                    shiftMonth.value
                    );
    
  });

  //シフト年月のプルダウンを生成する処理
  //年
  if(month===12){
    shiftYMHtml += `<option value="${year}" >${year}</option>`;
    shiftYMHtml += `<option value="${nextyear}"selected>${nextyear}</option>`;
  }else{
    shiftYMHtml += `<option value="${year}" selected>${year}</option>`;
  }
  shiftYear.innerHTML = shiftYMHtml;
  
  shiftYMHtml = "";
  //月
  shiftYMHtml += `<option value="${month}">${month}</option>`;
  shiftYMHtml += `<option value="${nextmonth}" selected>${nextmonth}</option>`;
  
  shiftMonth.innerHTML = shiftYMHtml;


/**
 * 年月を渡すとカレンダーを生成する処理
 * @param {カレンダーの年} yearparam
 * @param {カレンダーの月} monthparam
*/
function createCalendar(yearparam,monthparam){  

  console.log(yearparam,monthparam);
  const days = ["月", "火", "水", "木", "金", "土", "日"];
  const startDate = new Date(yearparam, monthparam - 1, 1); // 月の最初の日を取得
  const endDate = new Date(yearparam, monthparam, 0); // 月の最後の日を取得
  const endDayCount = endDate.getDate(); // 月の末日
  const lastMonthEndDate = new Date(yearparam, monthparam - 1, 0); // 前月の最後の日の情報
  const lastMonthEndDayCount = lastMonthEndDate.getDate(); // 前月の末日
  const startDay = startDate.getDay(); // 月の最初の日の曜日を取得

  //再描画に備えて初期化
  calendarHtml="";
  dayCount = 1;

  yearMonth.textContent = `${yearparam}年${monthparam}月`;
  
  calendarHtml += "<table><tr>";
  
  // 曜日の行を作成(テーブル1行目)
  for (let i = 0; i < days.length; i++) {
    calendarHtml += "<td class='day'>" + days[i] + "</td>";
  }

  calendarHtml += "</tr>";
  
  // 6週分
  for (let w = 0; w < 6; w++) {
    calendarHtml += "<tr>";
    
    for (let d = 0; d < 7; d++) {
      if (w == 0 && d < startDay - 1) {
        // 1行目で1日の前の日付
        let num = lastMonthEndDayCount - startDay + d + 2;
        calendarHtml += '<td class="is-disabled">' + num + "</td>";
      } else if (dayCount > endDayCount) {
        // 末尾の日数を超えた
        let num = dayCount - endDayCount;
        calendarHtml += '<td class="is-disabled">' + num + "</td>";
        dayCount++;
      } else {
        calendarHtml += `<td class="calendar_td" data-date="${yearparam}/${monthparam}/${dayCount}">${dayCount}</td>`;
        dayCount++;
      }
    }
    calendarHtml += "</tr>";
  }
  calendarHtml += "</table>";
  
  calendar.innerHTML = calendarHtml;
 
  //カレンダーの６行目が全て翌月分であれば、非表示にする処理
  const tr = document.querySelectorAll("#calendar tr");
  if (tr[6].firstChild.classList.contains("is-disabled")) {
    tr[6].remove();
  }

  //カレンダーが作成できた後に実行する
  if(calendar.innerHTML){
    //休日状態読込　の処理
    //holiday_ArrayがlocalStorageに保存できているか確認
    if(localStorage.getItem(yearparam.toString()+monthparam.toString()+'h')){
      //受け取ったJSONを配列に戻す
      let savedHolidays = JSON.parse(localStorage.getItem(yearparam.toString()+monthparam.toString()+'h'));
      activedays = document.querySelectorAll(".calendar_td");

      for(let i=0;i<savedHolidays.length;i++){
        activedays[savedHolidays[i]].classList.add('holiday-style');
      }
    }

    //有給状態読込　の処理
    //holiday_ArrayがlocalStorageに保存できているか確認
    if(localStorage.getItem(yearparam.toString()+monthparam.toString()+'p')){
      //受け取ったJSONを配列に戻す
      let savedPaidHolidays = JSON.parse(localStorage.getItem(yearparam.toString()+monthparam.toString()+'p'));
      activedays = document.querySelectorAll(".calendar_td");

      for(let i=0;i<savedPaidHolidays.length;i++){
        activedays[savedPaidHolidays[i]].classList.add('paid-holiday-style');
      }
    }

  }

}

});

/**
 * 有効な日付部をクリックした際の処理
 * 休日、有給休暇　判定用クラスの切り替え処理
 * 
 * calendar_td
 * calendar_td holiday-style
 * calendar_td paid-holiday-style 
 * calendar_td 
 */
document.addEventListener("click", function (e) {
  // e.targetがclassListプロパティを持っているかを確認
  if (e.target && e.target.classList) {
    if (e.target.classList.contains("calendar_td")) {
      // クリックした日付が有給であれば、有給を外す
      if (e.target.classList.contains("paid-holiday-style")) {
        console.log("paid holiday is clicked");
        e.target.classList.remove("paid-holiday-style");
      // クリックした日付が休日であれば、休日の代わりに有給をつける
      } else if (e.target.classList.contains("holiday-style")) {
        console.log("holiday is clicked");
        e.target.classList.remove("holiday-style");
        e.target.classList.add("paid-holiday-style");
      // クリックした日付が休日ではなければ休日を付与
      } else {
        console.log("weekday is clicked");
        e.target.classList.add("holiday-style");
      }
    }
  }
});
