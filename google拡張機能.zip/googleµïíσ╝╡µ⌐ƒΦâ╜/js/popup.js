//拡張機能上のスクリプト

console.log("this is popup.js");

//勤務パターン、出勤、退勤
const StartHh = document.getElementById("StartHh");
const StartMm = document.getElementById("StartMm");
const EndHh = document.getElementById("EndHh");
const EndMm = document.getElementById("EndMm");
const workPtn = document.getElementById("workPtn");

//読み込み時
document.addEventListener("DOMContentLoaded", function() {

  //勤務パターン、出勤、退勤　読み込み処理
  if(localStorage.getItem('StartHhValue')){
    StartHh.value = localStorage.getItem('StartHhValue');
  }

  if(localStorage.getItem('StartMmValue')){
    StartMm.value = localStorage.getItem('StartMmValue');
  }

  if(localStorage.getItem('EndHhValue')){
    EndHh.value = localStorage.getItem('EndHhValue');
  }

  if(localStorage.getItem('EndMmValue')){
    EndMm.value = localStorage.getItem('EndMmValue');
  }

  if(localStorage.getItem('workPtnValue')){
    workPtn.value = localStorage.getItem('workPtnValue');
  }  

  //一括セットクリック時
    document.getElementById("executeScript").addEventListener("click", function() {
      let StartHhValue = StartHh.value;
      let StartMmValue = StartMm.value;
      let EndHhValue = EndHh.value;
      let EndMmValue = EndMm.value;

      let workPtnValue = workPtn.value;

      let shiftMonthValue = shiftMonth.value;
      // console.log(shiftMonthValue);

      //勤務パターン、出勤、退勤　保存処理
      //出勤　時
      if(StartHhValue){
        localStorage.setItem('StartHhValue',StartHhValue);
        if(StartHh.classList.contains('check-style')){
          StartHh.classList.remove('check-style');
        }
      }else{
        alert("出勤時刻を入力してください")
        StartHh.classList.add('check-style');
      }

      //出勤　分
      if(StartMmValue){
        localStorage.setItem('StartMmValue',StartMmValue);
        if(StartMm.classList.contains('check-style')){
          StartMm.classList.remove('check-style');
        }
      }else{
        alert("出勤時刻を入力してください")
        StartMm.classList.add('check-style');
      }

      //退勤　時
      if(EndHhValue){
        localStorage.setItem('EndHhValue',EndHhValue);
        if(EndHh.classList.contains('check-style')){
          EndHh.classList.remove('check-style');
        }
      }else{
        alert("退勤時刻を入力してください")
        EndHh.classList.add('check-style');
      }

      //退勤　分
      if(EndMmValue){
        localStorage.setItem('EndMmValue',EndMmValue);
        if(EndMm.classList.contains('check-style')){
          EndMm.classList.remove('check-style');
        }
      }else{
        alert("退勤時刻を入力してください")
        EndMm.classList.add('check-style');
      }

      //勤務パターン
      if(workPtnValue){
        localStorage.setItem('workPtnValue',workPtnValue);
        if(workPtn.classList.contains('check-style')){
          workPtn.classList.remove('check-style');
        }
      }else{
        alert("勤務パターンを選択してください")
        workPtn.classList.add('check-style');
      }

      //休日状態保存の処理
      //休情報を保持する配列
      let holiday_Array = [];
      let activedays = document.querySelectorAll(".calendar_td");

      for(let i=0;i<activedays.length;i++){
        //activedaysのうち、休のクラスを持っているときのみ、配列にいれる。
        if(activedays[i].classList.contains("holiday-style")){
          // console.log(i,activedays[i]);
          holiday_Array.push(i);
        }
      }
      //配列をJSON形式に変換してlocalStorageへ保存
      localStorage.setItem(
                            shiftYear.value+shiftMonth.value + 'h',
                            JSON.stringify(holiday_Array)
                           );
      //有給状態保存の処理
      //有給状態を保持する配列
      let paid_holiday_Array = [];

      for(let i=0;i<activedays.length;i++){
        //activedaysのうち、休のクラスを持っているときのみ、配列にいれる。
        if(activedays[i].classList.contains("paid-holiday-style")){
          // console.log(i,activedays[i]);
          paid_holiday_Array.push(i);
        }
      }
      //配列をJSON形式に変換してlocalStorageへ保存
      localStorage.setItem(
                            shiftYear.value+shiftMonth.value + 'p',
                            JSON.stringify(paid_holiday_Array)
                           );

      //各週の最終　休日の日付を取得して格納しておく配列
      let last_holiday_Array = [];

      //calendar tr取得 0番目は除外 1行目からtdをチェック
      const calendar_tr = calendar.querySelectorAll('tr');
      for(let i=1;i<calendar_tr.length;i++){
        // console.log(i + "週目",calendar_tr[i]);
        //htd:各週の最終休日取得用
        let htd = calendar_tr[i].querySelectorAll('td.holiday-style');
        //エラー回避
        if (htd && htd.length > 0) {
          //holiday-styleをもつ、最終日の日付を取得して、配列に追加する。
          let lastHoliday = htd[htd.length-1];
          // 最終日のみ日曜色へ変更する対応のため
          if(lastHoliday && lastHoliday.innerText){
            // console.log(lastHoliday.innerText);
            last_holiday_Array.push(lastHoliday.innerText);
          }
        }
      }

      chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.scripting.executeScript({
          target: {tabId: tabs[0].id},
          function: executeContentScript,
          args: [StartHhValue,StartMmValue,EndHhValue,EndMmValue,workPtnValue,shiftMonthValue]
        });

        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
          chrome.scripting.executeScript({
            target: {tabId: tabs[0].id},
            function: setHolidayScript,
            args:[holiday_Array,paid_holiday_Array,last_holiday_Array,shiftMonthValue]
          });
        });
      });
    });

});

//e-革新へのリンク処理
document.getElementById("link").addEventListener('click',function(){
  chrome.tabs.create({url: 'https://www.e-kakushin.com/'});
});

/* 出勤時刻　退勤時刻 バリデーション */
StartHh.addEventListener('input', function() {
  let value = this.value.trim();

  // 全角数字を半角に変換
  value = value.replace(/[０-９]/g, function(char) {
    return String.fromCharCode(char.charCodeAt(0) - 0xFEE0);
  });

  // 数字以外の文字を削除
  value = value.replace(/[^0-9]/g, '');

  // 入力を２桁に制限
  value = value.substr(0, 2);

  this.value = value;
});
/* 出勤時刻　退勤時刻 バリデーション */
StartMm.addEventListener('input', function() {
  let value = this.value.trim();

  // 全角数字を半角に変換
  value = value.replace(/[０-９]/g, function(char) {
    return String.fromCharCode(char.charCodeAt(0) - 0xFEE0);
  });

  // 数字以外の文字を削除
  value = value.replace(/[^0-9]/g, '');

  // 入力を２桁に制限
  value = value.substr(0, 2);

  this.value = value;
});
/* 出勤時刻　退勤時刻 バリデーション */
EndHh.addEventListener('input', function() {
  let value = this.value.trim();

  // 全角数字を半角に変換
  value = value.replace(/[０-９]/g, function(char) {
    return String.fromCharCode(char.charCodeAt(0) - 0xFEE0);
  });

  // 数字以外の文字を削除
  value = value.replace(/[^0-9]/g, '');

  // 入力を２桁に制限
  value = value.substr(0, 2);

  this.value = value;
});
/* 出勤時刻　退勤時刻 バリデーション */
EndMm.addEventListener('input', function() {
  let value = this.value.trim();

  // 全角数字を半角に変換
  value = value.replace(/[０-９]/g, function(char) {
    return String.fromCharCode(char.charCodeAt(0) - 0xFEE0);
  });

  // 数字以外の文字を削除
  value = value.replace(/[^0-9]/g, '');

  // 入力を２桁に制限
  value = value.substr(0, 2);

  this.value = value;
});

//一括セット時、の処理
function executeContentScript(StartHhValue,StartMmValue,EndHhValue,EndMmValue,workPtnValue,shiftMonthValue) {
  // content.jsの関数を実行する
  myFunction(StartHhValue,StartMmValue,EndHhValue,EndMmValue, workPtnValue,shiftMonthValue);
}

//休日セット
function setHolidayScript(holiday_Array,paid_holiday_Array,last_holiday_Array,shiftMonthValue){
  setHoliday(holiday_Array,paid_holiday_Array,last_holiday_Array,shiftMonthValue);
}

  