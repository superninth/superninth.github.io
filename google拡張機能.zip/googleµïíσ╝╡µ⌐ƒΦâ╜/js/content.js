//e-革新上のスクリプト
console.log("this is content.js");

//全行取得
const rows = document.querySelectorAll('[id^=rowId]');
console.log(rows);
//行数
let rowsIndex = rows.length;

//e-革新上の各日付情報　締日判定用
let e_days = [];
let e_firstday_index = 0//ついたちの日付をもつindex
let e_first_row =""
let e_month = ""

for(let i=0;i<rowsIndex;i++){
    //e-革新上の日付情報を順に格納
    e_days.push(rows[i].children[2].innerText.replace(/\D/g,''));
    if(rows[i].children[2].innerText.startsWith('1(')){
        e_firstday_index = i;
        console.log(e_firstday_index);
    }
}

if(e_days.length){
    e_first_row = e_days[0];
    e_month = Number(document.getElementsByName('headMonth')[0].value).toString();
}

/**
 * 
 * @param {勤務開始時} StartHhValue 
 * @param {勤務開始分} StartMmValue
 * @param {勤務終了時} EndHhValue 
 * @param {勤務終了分} EndMmValue 
 * @param {勤務パターン} workPtnValue 
 * @param {shiftMonthValue} shfMonth セットしたときの月 String　比較用
 */
function myFunction(StartHhValue,StartMmValue,EndHhValue,EndMmValue,workPtnValue,shiftMonthValue){

    //debug用
    console.log(StartHhValue,StartMmValue,EndHhValue,EndMmValue, workPtnValue,shiftMonthValue);
    console.log(rows);

    for(let i=0;i<rowsIndex;i++){
        //出勤　と記載されているところは処理しない
        if( rows[i].children[4].children[0].value != "0000" &&
            shiftMonthValue === e_month
        ){

            //勤務パターンを指定のものにする　固定_8:00 
            rows[i].children[3].children[0].value = workPtnValue;
            
            //勤務状況　を空白に
            rows[i].children[4].children[0].value = "";
            
            //勤務時間を一括でセット
            document.getElementsByName(`workBeanList[${i}].scdBgnHh`)[0].value = StartHhValue
            document.getElementsByName(`workBeanList[${i}].scdBgnMi`)[0].value = StartMmValue
            document.getElementsByName(`workBeanList[${i}].scdEndHh`)[0].value = EndHhValue
            document.getElementsByName(`workBeanList[${i}].scdEndMi`)[0].value = EndMmValue
            
            changeAllColor();
        }   
    }
}


    //　カレンダーカラー
    var cldKbnTbl = new Array(
            
        '0',
        '#C1FAFB',

        '1',
        '#FF3399',

        '2',
        '#EE82EE',

        '3',
        '#FFC0CB',

    "");


var changeCldKbn = index => {
    var cldKbn = parseInt(document.forms[0]["workBeanList[" + index + "].cldKbn"].value);

    document.forms[0]["workBeanList[" + index + "].cldKbn"].value = cldKbnTbl[(cldKbn * 2 + 2) % 8];
    document.getElementById("rowId[" + index + "]").style.background = cldKbnTbl[(cldKbn * 2 + 3) % 8];
}

//色を勤務カラーの青に一括変更
var changeAllColor = () => {
    for(let i=0; i<rowsIndex;i++){
        // 背景色取得    
        let bgColor = rows[i].style.backgroundColor
        
        //日 3回実行
        if(bgColor=="rgb(255, 51, 153)"||bgColor=="FF3399"){
            for(let count_i=0;count_i<3;count_i++){
                changeCldKbn(i);
            }
        }
        //土曜 2回実行
        else if(bgColor=="rgb(238, 130, 238)"||bgColor=="EE82EE"){
            for(let count_i=0;count_i<2;count_i++){
                changeCldKbn(i);
            }
        }
        //祝 1回実行
        else if(bgColor=="rgb(255, 192, 203)"||bgColor=="EE82EE"){
            changeCldKbn(i);
        }
    }
}

let workStatus;

/**
 * 
 * @param {holiday_Array} h_array Number index + 1　で日付
 * @param {paid_holiday_Array} ph_array Number index + 1　で日付
 * @param {last_holiday_Array} lh_array 日付自体　String 
 * @param {shiftMonthValue} shfMonth セットしたときの月 String　比較用
 */
function setHoliday(h_array,ph_array,lh_array,shfMonth){

    console.log(h_array,ph_array,lh_array,shfMonth);
    
    //末締めの処理
    if(e_first_row === '1'){
        
        if(shfMonth === e_month){
            //メイン処理 
            for(let k=0;k<rowsIndex;k++){
                //出勤　と記載されているところは処理しない
                if(rows[k].children[4].children[0].value != "0000"){
                    //h_array に入っている休の数だけ比較する
                    if(h_array.length && h_array[h_array.length-1]){
                        
                        let count_i = 0;
                        while(count_i<h_array.length){
                            
                            if(String(h_array[count_i]+1) ===rows[k].children[2].innerText.replace(/\D/g,'')){   
                                rows[k].children[4].children[0].value = "0010";
                                rows[k].children[3].children[0].value = "";
                                
                                document.getElementsByName(`workBeanList[${k}].scdBgnHh`)[0].value = ""
                                document.getElementsByName(`workBeanList[${k}].scdBgnMi`)[0].value = ""
                                document.getElementsByName(`workBeanList[${k}].scdEndHh`)[0].value = ""
                                document.getElementsByName(`workBeanList[${k}].scdEndMi`)[0].value = ""
                                
                                changeCldKbn(k);
                                changeCldKbn(k);
                            }
                            
                            count_i++;
                        }
                        
                    }
                    
                    //ph_array に入っている有給の数だけ比較する
                    if(ph_array.length && ph_array[ph_array.length-1]){
                        
                        let count_i = 0;
                        while(count_i<ph_array.length){
                            
                            if(String(ph_array[count_i]+1) ===rows[k].children[2].innerText.replace(/\D/g,'')){   
                                rows[k].children[4].children[0].value = "0030";
                            }
                            
                            count_i++;
                        }                    
                    }
                    
                    //lh_array に入っている「週最後の休」の数だけ比較する
                    if(lh_array.length && lh_array[lh_array.length-1]){
                        console.log("週の最後の休",lh_array);
                        
                        let count_i = 0;
                        while(count_i<lh_array.length){
                            console.log(lh_array[count_i]);
                            
                            if(lh_array[count_i] === rows[k].children[2].innerText.replace(/\D/g,'')){   
                                rows[k].children[4].children[0].value = "0010";
                                rows[k].children[3].children[0].value = "";
                                
                                document.getElementsByName(`workBeanList[${k}].scdBgnHh`)[0].value = ""
                                document.getElementsByName(`workBeanList[${k}].scdBgnMi`)[0].value = ""
                                document.getElementsByName(`workBeanList[${k}].scdEndHh`)[0].value = ""
                                document.getElementsByName(`workBeanList[${k}].scdEndMi`)[0].value = ""
                                
                                changeCldKbn(k);
                                changeCldKbn(k);
                                changeCldKbn(k);
                            }
                            
                            count_i++;
                        }
                    }
                }
            }        
        }else{
            alert('対象月を確認してください。処理を中止します。');
        }
            
    //20日締めの処理
    }else if(e_first_row === '21'){
        //出勤　と記載されているところは処理しない
        if(rows[k].children[4].children[0].value != "0000"){
            //当月　1~20までのみ処理する
            if(shfMonth === e_month){
                
                for(let k=e_firstday_index;k<rowsIndex;k++){
                    //h_array に入っている休の数だけ比較する
                    if(h_array.length && h_array[h_array.length-1]){
                        
                        let count_i = 0;
                        while(count_i<h_array.length){
                            
                            if(String(h_array[count_i]+1) ===rows[k].children[2].innerText.replace(/\D/g,'')){   
                                rows[k].children[4].children[0].value = "0010";
                                rows[k].children[3].children[0].value = "";
                                
                                document.getElementsByName(`workBeanList[${k}].scdBgnHh`)[0].value = ""
                                document.getElementsByName(`workBeanList[${k}].scdBgnMi`)[0].value = ""
                                document.getElementsByName(`workBeanList[${k}].scdEndHh`)[0].value = ""
                                document.getElementsByName(`workBeanList[${k}].scdEndMi`)[0].value = ""
                                
                                changeCldKbn(k);
                                changeCldKbn(k);
                            }
                            
                            count_i++;
                        }
                        
                    }
                    
                    //ph_array に入っている有給の数だけ比較する
                    if(ph_array.length && ph_array[ph_array.length-1]){
                        
                        let count_i = 0;
                        while(count_i<ph_array.length){
                            
                            if(String(ph_array[count_i]+1) ===rows[k].children[2].innerText.replace(/\D/g,'')){   
                                rows[k].children[4].children[0].value = "0030";
                            }
                            
                            count_i++;
                        }                    
                    }
                    
                    //lh_array に入っている「週最後の休」の数だけ比較する
                    if(lh_array.length && lh_array[lh_array.length-1]){
                        console.log("週の最後の休",lh_array);
                        
                        let count_i = 0;
                        while(count_i<lh_array.length){
                            console.log(lh_array[count_i]);
                            
                            if(lh_array[count_i] === rows[k].children[2].innerText.replace(/\D/g,'')){   
                                rows[k].children[4].children[0].value = "0010";
                                rows[k].children[3].children[0].value = "";
                                
                                document.getElementsByName(`workBeanList[${k}].scdBgnHh`)[0].value = ""
                                document.getElementsByName(`workBeanList[${k}].scdBgnMi`)[0].value = ""
                                document.getElementsByName(`workBeanList[${k}].scdEndHh`)[0].value = ""
                                document.getElementsByName(`workBeanList[${k}].scdEndMi`)[0].value = ""
                                
                                changeCldKbn(k);
                                changeCldKbn(k);
                                changeCldKbn(k);
                            }
                            
                            count_i++;
                        }
                    }
                }
                
            //翌月　21~e_firstday_index - 1(月の末日)までのみ処理する
            }else if(Number(shfMonth) === Number(e_month) - 1){
                for(let k=0;k<e_firstday_index;k++){
                    //h_array に入っている休の数だけ比較する
                    if(h_array.length && h_array[h_array.length-1]){

                        let count_i = 0;
                        while(count_i<h_array.length){

                            if(String(h_array[count_i]+1) ===rows[k].children[2].innerText.replace(/\D/g,'')){   
                                rows[k].children[4].children[0].value = "0010";
                                rows[k].children[3].children[0].value = "";

                                document.getElementsByName(`workBeanList[${k}].scdBgnHh`)[0].value = ""
                                document.getElementsByName(`workBeanList[${k}].scdBgnMi`)[0].value = ""
                                document.getElementsByName(`workBeanList[${k}].scdEndHh`)[0].value = ""
                                document.getElementsByName(`workBeanList[${k}].scdEndMi`)[0].value = ""

                                changeCldKbn(k);
                                changeCldKbn(k);
                            }

                            count_i++;
                        }
                        
                    }

                    //ph_array に入っている有給の数だけ比較する
                    if(ph_array.length && ph_array[ph_array.length-1]){

                        let count_i = 0;
                        while(count_i<ph_array.length){

                            if(String(ph_array[count_i]+1) ===rows[k].children[2].innerText.replace(/\D/g,'')){   
                                rows[k].children[4].children[0].value = "0030";
                            }

                            count_i++;
                        }                    
                    }
                    
                    //lh_array に入っている「週最後の休」の数だけ比較する
                    if(lh_array.length && lh_array[lh_array.length-1]){
                        console.log("週の最後の休",lh_array);

                        let count_i = 0;
                        while(count_i<lh_array.length){
                            console.log(lh_array[count_i]);

                            if(lh_array[count_i] === rows[k].children[2].innerText.replace(/\D/g,'')){   
                                rows[k].children[4].children[0].value = "0010";
                                rows[k].children[3].children[0].value = "";

                                document.getElementsByName(`workBeanList[${k}].scdBgnHh`)[0].value = ""
                                document.getElementsByName(`workBeanList[${k}].scdBgnMi`)[0].value = ""
                                document.getElementsByName(`workBeanList[${k}].scdEndHh`)[0].value = ""
                                document.getElementsByName(`workBeanList[${k}].scdEndMi`)[0].value = ""

                                changeCldKbn(k);
                                changeCldKbn(k);
                                changeCldKbn(k);
                            }

                            count_i++;
                        }
                    }
               }
            }
        }
    }
    
}



